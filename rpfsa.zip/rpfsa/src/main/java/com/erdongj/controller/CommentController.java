package com.erdongj.controller;

import com.erdongj.pojo.Comment;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: Erdong J
 * @Date: 2023/5/3 17:30
 * @Description:
 */

@RestController
@CrossOrigin
@RequestMapping("/comment")
public class CommentController extends BaseController {

    @Autowired
    private CommentService commentService;

    @PostMapping
    public ResultBean addonecomment(@RequestBody Comment comment) {
        return commentService.addonecomment(comment) ? successful("评论成功") : faile("评论失败");
    }

    @DeleteMapping("/{id}")
    public ResultBean deletetype2comment(@PathVariable Integer id) {
        return commentService.deletetypetwocomment(id) ? successful("删除成功") : faile("删除失败");
    }

    @DeleteMapping("/t1/{id}")
    public ResultBean deletetype1comment(@PathVariable Integer id){
        int commentCount = commentService.deletetypeonecomment(id);
        return commentCount == 0?faile("删除失败"):successful("删除成功",commentCount);
    }

}
