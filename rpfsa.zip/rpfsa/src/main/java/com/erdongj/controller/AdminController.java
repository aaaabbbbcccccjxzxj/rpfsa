package com.erdongj.controller;

import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.Admin;
import com.erdongj.pojo.ResultBean;
import com.erdongj.pojo.User;
import com.erdongj.service.AdminService;
import com.erdongj.service.MessageService;
import com.erdongj.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @description: 管理员交互层
 * @author: Erdong J
 * @create: 2023-03-08 21:35
 **/

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController extends BaseController {
    @Autowired
    private AdminService adminService;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private MessageService messageService;

    @PostMapping("/login")
    public ResultBean login(@RequestBody Admin admin) {
        return adminService.Login(admin.getAdminname(), admin.getPassword()) ? successful("登录成功") : faile("管理员不存在或密码错误");
    }

    @GetMapping
    public ResultBean getallinfo() {
        Map<String, Long> map = adminService.getallinfo();
        //查找目前所有未读的消息
        List<User> users = userMapper.selectList(null);
        Long messageCount = 0L;
        for (User user : users) {
            Long eachCount = messageService.queryallnoread(user.getId(), "admin");
            messageCount += eachCount;
        }
        map.put("messageCount", messageCount);
        return successful("查询成功", map);
    }
}

