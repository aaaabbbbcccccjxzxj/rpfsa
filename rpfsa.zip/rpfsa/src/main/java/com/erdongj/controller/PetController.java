package com.erdongj.controller;

import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Pet;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/10 10:09
 * @Description:
 */

@RestController
@RequestMapping("/pet")
@CrossOrigin
public class PetController extends BaseController {

    @Autowired
    private PetService petService;

    @GetMapping("/page/{c}")
    public ResultBean getpetsbypage(@PathVariable("c") int current) {
        Pagination pagination = petService.querypetsbypage(current, null);
        return pagination.getTotal() == 0 ? faile("无宠物信息") : successful("查询成功", pagination);
    }

    @GetMapping("/{c}/{col}/{con}")
    public ResultBean likequery(@PathVariable(value = "c") int current,
                                @PathVariable(value = "col") String column,
                                @PathVariable(value = "con") String condition) {
        Pagination pagination = petService.conditionquery(current, column, condition);
        return pagination.getTotal() == 0 ? faile("无符合结果") : successful("查询成功", pagination);
    }

    @GetMapping
    public ResultBean get10pets() {
        return successful("排行前十", petService.queryallpets());
    }

    @GetMapping("/{id}")
    public ResultBean getonebyid(@PathVariable Integer id) {
        Pet pet = petService.queryonebyID(id);
        return pet == null ? faile("无结果") : successful("查询成功", pet);
    }

    @GetMapping("/mypets/{id}")
    public ResultBean getmypetsbyid(@PathVariable int id) {
        List<Pet> petList = petService.querypetbyuid(id);
        return petList.isEmpty() ? faile("暂无宠物数据") : successful("查询成功", petList);
    }


    /**
     * 根据id删除一个猫狗
     *
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public ResultBean deletepetbyid(@PathVariable("id") Integer id) {
        return petService.deleteonebyID(id) ? successful("删除成功") : faile("删除失败");
    }

    /**
     * 添加一个猫狗
     *
     * @param pet
     * @return
     */
    @PostMapping
    public ResultBean addonepet(@RequestBody Pet pet) {
        return petService.addonepet(pet) ? successful("添加成功") : faile("添加失败");
    }

    /**
     * 修改猫狗信息(ps:局部修改用patch)
     *
     * @param pet
     * @return
     */
    @PatchMapping
    public ResultBean updateonepet(@RequestBody Pet pet) {
        return petService.updateonepet(pet) ? successful("修改成功") : faile("修改失败");
    }
}
