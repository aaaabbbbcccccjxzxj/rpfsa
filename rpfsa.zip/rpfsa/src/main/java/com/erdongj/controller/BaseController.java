package com.erdongj.controller;

import com.erdongj.pojo.ResultBean;

/**
 * @Author: Erdong J
 * @Date: 2023/5/27 15:27
 * @Description: 所有控制类的基类
 */
public abstract class BaseController {
    private final int SUCCESSFUL = 200;
    private final int FAILE = 0;

    /**
     * 调方法生成ResultBean,不用再new了
     * @param code
     * @param msg
     * @param data
     * @return
     */
    ResultBean convert(int code,String msg,Object data){
        return new ResultBean(code,msg,data);
    }
    /**
     * 成功 成功消息 无结果
     * @param msg
     * @return
     */
    protected ResultBean successful(String msg){
        return convert(SUCCESSFUL,msg,null);
    }

    /**
     * 成功 成功消息 结果
     * @param msg
     * @param data
     * @return
     */
    protected ResultBean successful(String msg,Object data){
        return convert(SUCCESSFUL,msg,data);
    }

    /**
     * 失败 失败消息 无结果
     * @param msg
     * @return
     */
    protected ResultBean faile(String msg){
        return convert(FAILE,msg,null);
    }

}
