package com.erdongj.controller;

import com.erdongj.pojo.Food;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/5/6 09:02
 * @Description:
 */

@RestController
@RequestMapping("/food")
@CrossOrigin
public class FoodController extends BaseController {

    @Autowired
    private FoodService foodService;

    @GetMapping
    public ResultBean getallfoods() {
        List<Food> foodList = foodService.queryallfoods();
        return foodList.isEmpty() ? faile("平台暂无救助品") : successful("查询成功", foodList);
    }

    @PostMapping
    public ResultBean addonefood(@RequestBody Food food) {
        return foodService.addonefood(food) ? successful("添加成功！") : faile("添加失败");
    }

    @DeleteMapping("/{id}")
    public ResultBean deleteonefood(@PathVariable Integer id) {
        return foodService.deleteonefood(id) ? successful("删除成功！") : faile("删除失败");
    }

    @PatchMapping
    public ResultBean updatefood(@RequestBody Food food) {
        return foodService.updatefood(food) ? successful("修改成功！") : faile("修改失败");
    }

}
