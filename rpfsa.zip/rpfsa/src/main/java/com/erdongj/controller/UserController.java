package com.erdongj.controller;

import com.erdongj.pojo.Adopt;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.ResultBean;
import com.erdongj.pojo.User;
import com.erdongj.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @description: 用户控制层
 * @author: Erdong J
 * @create: 2023-03-17 21:09
 **/
@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController extends BaseController {

    @Autowired
    private UserService userService;

    @GetMapping("/page/{c}")
    public ResultBean getusersbypage(@PathVariable("c") int current) {
        Pagination pagination = userService.queryusersbypage(current, null);
        return pagination.getTotal() == 0 ? faile("无用户信息") : successful("查询成功", pagination);
    }

    @GetMapping("/{c}/{col}/{con}")
    public ResultBean likequery(@PathVariable(value = "c") int current,
                                @PathVariable(value = "col") String column,
                                @PathVariable(value = "con") String condition) {
        Pagination pagination = userService.likequery(current, column, condition);
        return pagination.getTotal() == 0 ? faile("无符合结果") : successful("查询成功", pagination);
    }

    /**
     * 根据用户id查询该用户的领养情况
     *
     * @param uid
     * @return
     */
    @GetMapping("/myadopt/{uid}")
    public ResultBean getmyadopt(@PathVariable Integer uid) {
        List<Adopt> adoptList = userService.querymyadopt(uid);
        return adoptList.isEmpty() ? faile("暂无领养") : successful("查询成功", adoptList);
    }

    /**
     * 根据id删除一个用户
     *
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public ResultBean deleteuserbyid(@PathVariable("id") Integer id) {
        return userService.deleteonebyID(id) ? successful("删除成功") : faile("删除失败");
    }

    /**
     * 添加一个用户
     *
     * @param user
     * @return
     */
    @PostMapping
    public ResultBean addoneuser(@RequestBody User user) {
        return userService.addoneuser(user) ? successful("添加成功") : faile("用户名已存在！");
    }

    /**
     * 修改用户信息(ps:局部修改用patch)
     *
     * @param user
     * @return
     */
    @PatchMapping
    public ResultBean updateoneuser(@RequestBody User user) {
        return userService.updateoneuser(user) ? successful("修改成功") : faile("修改失败");
    }

    /**
     * 用户登录功能
     *
     * @param user
     * @return
     */
    @PostMapping("/login")
    public ResultBean userlogin(@RequestBody User user) {
        User isuser = userService.userlogin(user.getUsername(), user.getPassword());
        return isuser == null ? faile("对不起,用户名不存在或密码错误") : successful("登录成功", isuser);
    }

    /**
     * 根据id查询一个用户
     *
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public ResultBean getuserbyid(@PathVariable Integer id) {
        User user = userService.queryonebyID(id);
        return user == null ? faile("用户名不存在") : successful("查询成功", user);
    }

    /**
     * 获取排行前10的用户
     *
     * @return
     */
    @GetMapping
    public ResultBean get10users() {
        return successful("查询成功", userService.queryallusers());
    }
}
