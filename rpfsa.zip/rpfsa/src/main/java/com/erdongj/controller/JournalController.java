package com.erdongj.controller;

import com.erdongj.pojo.Journal;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.JournalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/6/3 16:05
 * @Description:
 */
@RestController
@RequestMapping("/journal")
@CrossOrigin
public class JournalController extends BaseController {

    @Autowired
    private JournalService journalService;

    @PostMapping
    public ResultBean addonejournal(@RequestBody Journal journal) {
        return journalService.addonejournal(journal) ? successful("添加成功") : faile("添加失败");
    }

    @DeleteMapping("/{id}")
    public ResultBean deleteonejournal(@PathVariable int id) {
        return journalService.deleteonejournal(id) ? successful("删除成功") : faile("删除失败");
    }

    @GetMapping("/{pid}")
    public ResultBean queryalljournal(@PathVariable int pid) {
        List<Journal> list = journalService.queryonepetbyid(pid);
        return list.isEmpty() ? faile("暂无动态记录") : successful("查询成功", list);
    }
}
