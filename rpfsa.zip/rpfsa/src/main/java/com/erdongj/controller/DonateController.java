package com.erdongj.controller;

import com.erdongj.pojo.Donate;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.DonateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @Author: Erdong J
 * @Date: 2023/5/6 21:05
 * @Description:
 */
@RestController
@RequestMapping("/donate")
@CrossOrigin
public class DonateController extends BaseController {

    @Autowired
    private DonateService donateService;

    @PostMapping
    public ResultBean addonedonate(@RequestBody Donate donate) {
        return donateService.addonedonate(donate) ? successful("捐助成功,感谢您的爱心！") : faile("捐助失败");
    }

    @GetMapping
    public ResultBean query10donates() {
        List<Map<String, Object>> maps = donateService.query10user();
        return maps.isEmpty() ? faile("暂无数据") : successful("查询成功",maps);
    }

    @GetMapping("/{id}")
    public ResultBean queryall(@PathVariable("id") Integer id) {
        List<Donate> donateList = donateService.queryalldonatebyid(id);
        return donateList.isEmpty() ? faile("暂无捐献记录") : successful("查询成功", donateList);
    }

    @GetMapping("/noread/{uid}")
    public ResultBean getallnoread(@PathVariable Integer uid) {
        return successful("查询成功", donateService.queryallnoread(uid));
    }

    @GetMapping("/page/{c}")
    public ResultBean queryallbypage(@PathVariable("c") int current) {
        Pagination pageinfo = donateService.queryalldonatebypage(current, null);
        return pageinfo.getTotal() == 0 ? faile("暂无捐助记录") : successful("查询成功", pageinfo);
    }

    @GetMapping("/{c}/{col}/{con}")
    public ResultBean conditionquery(@PathVariable("c") int current,
                                     @PathVariable("col") String column,
                                     @PathVariable("con") String condition) {
        Pagination pagination = donateService.conditionquery(current, column, condition);
        return pagination.getTotal() == 0 ? faile("无符合结果") : successful("查询成功", pagination);
    }

    @PatchMapping
    public ResultBean updatestate(@RequestBody Donate donate) {
        return donateService.updatedonatestate(donate) ? successful("通知已发送") : faile("出现错误");
    }

    @PatchMapping("/{id}")
    public ResultBean haveread(@PathVariable Integer id) {
        donateService.readalladopt(id);
        return successful("所有消息已读成功");
    }
}
