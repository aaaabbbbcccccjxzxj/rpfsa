package com.erdongj.controller;

import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Post;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:46
 * @Description:
 */

@RestController
@RequestMapping("/post")
@CrossOrigin
public class PostController extends BaseController {

    @Autowired
    private PostService postService;

    @PostMapping
    public ResultBean addonepost(@RequestBody Post post) {
        return postService.addonepost(post) ? successful("添加成功") : faile("添加失败");
    }


    @GetMapping
    public ResultBean get10posts() {
        return successful("排行榜前十", postService.query10posts());
    }

    /**
     * 用户网站首页  公告和more来用
     *
     * @param classic
     * @return
     */
    @GetMapping("/alltypeone/{cl}")
    public ResultBean getall(@PathVariable("cl") int classic) {
        List<Post> postList = postService.queryall(classic);
        return postList.isEmpty() ? faile("暂无数据") : successful("公告信息", postList);
    }

    @GetMapping("/{id}")
    public ResultBean getonepostbyid(@PathVariable Integer id) {
        Post post = postService.queryonepostbyid(id);
        return post == null ? faile("不存在") : successful("查询成功", post);
    }

    /**
     * 查询某用户的所有帖子
     *
     * @param id
     * @return
     */
    @GetMapping("/my/{id}")
    public ResultBean getmypostsbyid(@PathVariable Integer id) {
        List<Post> postList = postService.queryallmypostbyid(id);
        return postList.isEmpty() ? faile("暂无发帖信息") : successful("查询成功", postList);
    }

    @GetMapping(path = {"/{c}/{t}", "/{c}/{t}/{col}/{con}"})
    public ResultBean getpostsbypage(@PathVariable("c") int current,
                                     @PathVariable("t") int type,
                                     @PathVariable(value = "col", required = false) String column,
                                     @PathVariable(value = "con", required = false) String condition) {
        Pagination pagination = postService.queryallpostsbypage(current, type, column, condition);
        return pagination.getTotal() == 0 ? faile("暂无数据") : successful("查询成功", pagination);
    }

    @DeleteMapping("/{id}")
    public ResultBean deleteonepost(@PathVariable Integer id) {
        return postService.deleteonepost(id) ? successful("删除成功") : faile("删除失败");
    }

    @PatchMapping
    public ResultBean addpostcommentcount(@RequestBody Post post) {
        return postService.updatecommentcount(post) ? successful("评论已添加") : faile("评论添加失败");
    }
}
