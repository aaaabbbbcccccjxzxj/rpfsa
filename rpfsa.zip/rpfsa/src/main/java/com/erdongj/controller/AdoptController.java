package com.erdongj.controller;

import com.erdongj.pojo.Adopt;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.AdoptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: Erdong J
 * @Date: 2023/4/23 11:15
 * @Description:
 */

@RestController
@RequestMapping("/adopt")
@CrossOrigin
public class AdoptController extends BaseController {

    @Autowired
    private AdoptService adoptService;

    @PostMapping
    public ResultBean createadopttable(@RequestBody Adopt adopt) {
        return adoptService.addadopttable(adopt) ? successful("申请成功！请注意查看通知") : faile("申请失败");
    }

    @GetMapping("/{c}")
    public ResultBean getadoptsbypage(@PathVariable("c") int current) {
        Pagination pageinfo = adoptService.queryadoptsbypage(current, null);
        return pageinfo.getTotal() == 0 ? faile("暂无申请信息") : successful("查询成功", pageinfo);
    }

    @GetMapping("/{c}/{col}/{con}")
    public ResultBean conditionquery(@PathVariable("c") int current,
                                     @PathVariable("col") String column,
                                     @PathVariable("con") String condition) {
        Pagination pagination = adoptService.conditionquery(current, column, condition);
        return pagination.getTotal() == 0 ? faile("无查询结果") : successful("查询成功", pagination);
    }

    @GetMapping("/noread/{uid}")
    public ResultBean getallnoread(@PathVariable Integer uid) {
        return successful("查询成功", adoptService.queryallonread(uid));
    }

    @PatchMapping
    public ResultBean updatestate(@RequestBody Adopt adopt) {
        return adoptService.auditstatus(adopt) ? successful("通知已发送") : faile("出现错误");
    }

    @PatchMapping("/{uid}")
    public ResultBean readall(@PathVariable Integer uid) {
        return adoptService.readalladopt(uid) ? successful("消息已读") : faile("出现错误");
    }
}
