package com.erdongj.controller;

import com.erdongj.pojo.Message;
import com.erdongj.pojo.ResultBean;
import com.erdongj.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/5/9 15:30
 * @Description:
 */

@RestController
@RequestMapping("/message")
@CrossOrigin
public class MessageController extends BaseController {

    @Autowired
    private MessageService messageService;


    @PostMapping
    public ResultBean addonemessage(@RequestBody Message message) {
        return messageService.addonemessage(message) ? successful("发送成功") : faile("发送失败");
    }

    @GetMapping("/{uid}")
    public ResultBean getallmessagesbyid(@PathVariable Integer uid) {
        return  successful("查询成功", messageService.queryallmessagebyid(uid));
    }

    @GetMapping("/noread/{uid}/{identity}")
    public ResultBean getnoreadbyid(@PathVariable Integer uid,
                                    @PathVariable String identity) {
        return successful("查询成功", messageService.queryallnoread(uid, identity));
    }

    @PatchMapping("/{uid}/{identity}")
    public ResultBean readallmessage(@PathVariable Integer uid,
                                     @PathVariable String identity) {
        return successful("已读所有消息", messageService.allhaveread(uid, identity));
    }
}
