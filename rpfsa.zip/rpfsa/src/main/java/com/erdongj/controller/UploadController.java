package com.erdongj.controller;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @description: 头像上传
 * @author: Erdong J
 * @create: 2023-03-14 22:18
 **/
@Controller
@CrossOrigin
public class UploadController {

    @ResponseBody
    @PostMapping("/upload")
    //文件上传步骤
    //1.用MultipartFile 类型来接收前端发送的文件
    public String upload(MultipartFile file) throws FileNotFoundException {

//        2.获取到文件的全名
        String filename = file.getOriginalFilename();
//        3.给文件一个全新的名字
        String newname = System.currentTimeMillis() + filename.substring(filename.lastIndexOf("."));


//        4.设置文件要存储的目录
        String path = ResourceUtils.getURL("classpath:").getPath() + "static/img/";
        //copy 一份图片到项目路径下,以便重启服务器不会照成丢失
        String copypath = "src/main/resources/static/img/";
        System.out.println(path);
        System.out.println(copypath);
//        5.把这个目录文件创建出来,ps:普通文件是文件，目录也是文件.注意这里只是创建出来个File java类对象.此时还没有目录
        File newpath = new File(path);
        File fcopypath = new File(copypath);
//        6.判断这个目录文件是否存在,不存在就创建出来.此时这个目录就出现了
        if (!newpath.exists()) newpath.mkdirs();
        if (!fcopypath.exists()) fcopypath.mkdirs();

        try {
//        7.根据newpath和newname创建一个全新的 File 实例
            File newfile = new File(newpath, newname);//新的是这个:     D:\Users\10139\Pictures\Saved Pictures\xxxxxxxxx.txt
//        8.把前端的初始file 转化为 全新的 newfile
            file.transferTo(newfile);                //前端传来的是:    X:\xxx\xx\xxxx\xxxxx\xxxxxxxxx.txt

            //复制！
            FileUtils.copyFileToDirectory(newfile,fcopypath);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        return newname;
    }
}

