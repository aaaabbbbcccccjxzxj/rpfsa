package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.erdongj.mapper.MessageMapper;
import com.erdongj.pojo.Donate;
import com.erdongj.pojo.Message;
import com.erdongj.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/5/9 15:28
 * @Description:
 */
@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageMapper messageMapper;
    @Override
    public boolean addonemessage(Message message) {
        return messageMapper.insert(message) == 1;
    }

    @Override
    public List<Message> queryallmessagebyid(Integer uid) {
        LambdaQueryWrapper<Message> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Message::getUid,uid).orderByAsc(Message::getCreateTime);
        return messageMapper.selectList(lqw);
    }

    @Override
    public Long queryallnoread(Integer uid,String identity) {
        LambdaQueryWrapper<Message> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Message::getUid, uid)
                .isNotNull(identity.equals("user"),Message::getContent)
                .isNotNull(identity.equals("admin"),Message::getUserReply)
                .eq(Message::getIsRead,1);
        return messageMapper.selectCount(lqw);
    }

    @Override
    public boolean allhaveread(Integer uid,String identity) {
        LambdaQueryWrapper<Message> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Message::getUid,uid)
                .isNotNull(identity.equals("user"),Message::getContent)
                .isNotNull(identity.equals("admin"),Message::getUserReply)
                .eq(Message::getIsRead,1);
        List<Message> messageList = messageMapper.selectList(lqw);
        for (Message message : messageList) {
            message.setIsRead(0);
            messageMapper.updateById(message);
        }
        return true;
    }
}
