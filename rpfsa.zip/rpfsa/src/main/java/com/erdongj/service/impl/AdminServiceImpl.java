package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.mapper.*;
import com.erdongj.pojo.*;
import com.erdongj.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author: Erdong J
 * @create: 2023-03-08 21:25
 **/
@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PetMapper petMapper;
    @Autowired
    private AdoptMapper adoptMapper;
    @Autowired
    private DonateMapper donateMapper;
    @Autowired
    private PostMapper postMapper;

    /**
     * 管理员登录验证
     *
     * @param name
     * @param password
     * @return
     */
    @Override
    public boolean Login(String name, String password) {
        boolean isright = false;
        LambdaQueryWrapper<Admin> lqw = new LambdaQueryWrapper<>();
        //查找数据库中是否有该管理员？不再一一判断了。
        lqw.eq(Admin::getAdminname, name).eq(Admin::getPassword, password);
        Admin admin = adminMapper.selectOne(lqw);
        if (admin != null) isright = true;
        return isright;
    }

    /**
     * 后台管理员查看总信息。
     *
     * @return
     */
    @Override
    public Map<String, Long> getallinfo() {
        Map<String, Long> map = new HashMap<>();
        //用户数量
        map.put("userCount", userMapper.selectCount(null));
        //流浪猫狗总数数量
        map.put("petCount", petMapper.selectCount(null));
        map.put("type0petCount", petMapper.selectCount(new QueryWrapper<Pet>().eq("type", 0)));
        map.put("type1petCount", petMapper.selectCount(new QueryWrapper<Pet>().eq("type", 1)));
        map.put("state0petCount", petMapper.selectCount(new QueryWrapper<Pet>().eq("is_adopt", 0)));
        map.put("state1petCount", petMapper.selectCount(new QueryWrapper<Pet>().eq("is_adopt", 1)));
        map.put("state2petCount", petMapper.selectCount(new QueryWrapper<Pet>().eq("is_adopt", 2)));
        //用户发帖数量
        map.put("postCount", postMapper.selectCount(new QueryWrapper<Post>().ne("uid", 0)));
        //未处理领养申请数量
        map.put("adoptCount", adoptMapper.selectCount(new QueryWrapper<Adopt>().eq("state", 2)));
        map.put("haveAdoptCount", adoptMapper.selectCount(new QueryWrapper<Adopt>().eq("state", 1)));
        //未分配的救助品数量
        map.put("donateCount", donateMapper.selectCount(new QueryWrapper<Donate>().eq("state", 0)));
        map.put("haveDonateCount", donateMapper.selectCount(new QueryWrapper<Donate>().eq("state", 1)));
        //未读消息
        return map;
    }
}

