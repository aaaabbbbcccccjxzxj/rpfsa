package com.erdongj.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.pojo.Adopt;
import com.erdongj.pojo.Pagination;

/**
 * @Author: Erdong J
 * @Date: 2023/4/23 09:48
 * @Description:
 */
public interface AdoptService {


    /**
     * 可按条件分页查询
     *
     * @param current
     * @param qw
     * @return
     */
    Pagination queryadoptsbypage(int current, QueryWrapper qw);

    /**
     * 产生条件查询,调用分页
     *
     * @param current
     * @param column
     * @param condition
     * @return
     */
    Pagination conditionquery(int current, String column, String condition);

    /**
     * 添加一张领养表
     *
     * @param adopt
     * @return
     */
    boolean addadopttable(Adopt adopt);

    /**
     * 删除一张表
     *
     * @param id 领养表id
     * @return
     */
    boolean deleteone(Integer id);

    /**
     * 修改审核状态
     *
     * @param adopt 表对象
     * @return
     */
    boolean auditstatus(Adopt adopt);

    /**
     * 用户已读所有领养申请通知
     *
     * @return
     */
    boolean readalladopt(Integer uid);

    /**
     * 用户查询所有领养申请未读通知
     *
     * @param uid
     * @return
     */
    Long queryallonread(Integer uid);
}
