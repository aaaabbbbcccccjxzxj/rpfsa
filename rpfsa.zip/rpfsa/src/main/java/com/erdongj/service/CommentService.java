package com.erdongj.service;

import com.erdongj.pojo.Comment;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:37
 * @Description:
 */
public interface CommentService {

    /**
     * 添加一个评论
     * @param comment
     * @return
     */
    boolean addonecomment(Comment comment);

    /**
     * 根据id删除一个二级评论
     * @param id
     * @return
     */
    boolean deletetypetwocomment(Integer id);

    /**
     * 根据id删除一个一级评论,一级评论下可能有二级评论
     * @param id
     * @return
     */
    int deletetypeonecomment(Integer id);
}
