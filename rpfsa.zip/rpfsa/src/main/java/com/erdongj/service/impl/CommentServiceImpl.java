package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.mapper.CommentMapper;
import com.erdongj.pojo.Comment;
import com.erdongj.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:40
 * @Description:
 */
@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentMapper commentMapper;
    @Override
    @Transactional
    public boolean addonecomment(Comment comment) {
        return commentMapper.insert(comment) == 1;
    }

    @Override
    @Transactional
    public int deletetypeonecomment(Integer id) {
        QueryWrapper<Comment> qw = new QueryWrapper<>();
        //把一级评论删了
        qw.eq("id",id).or().eq("level",id);
        int deleteCount = commentMapper.delete(qw);
        return deleteCount;
    }

    @Override
    @Transactional
    public boolean deletetypetwocomment(Integer id) {
        return commentMapper.deleteById(id) == 1;
    }
}
