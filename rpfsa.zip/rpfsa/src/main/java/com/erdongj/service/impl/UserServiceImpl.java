package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.erdongj.mapper.AdoptMapper;
import com.erdongj.mapper.PetMapper;
import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.*;
import com.erdongj.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @description:
 * @author: Erdong J
 * @create: 2023-03-16 21:37
 **/
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private PetMapper petMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private AdoptMapper adoptMapper;

    @Override
    public List<User> queryallusers() {
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.orderByDesc(User::getHowAdopt).last("limit 10");
        return userMapper.selectList(lqw);
    }

    @Override
    public User queryonebyID(Integer id) {
        return userMapper.selectById(id);
    }

    @Override
    public List<Adopt> querymyadopt(Integer uid) {
        LambdaQueryWrapper<Adopt> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Adopt::getUid, uid);
        List<Adopt> adoptList = adoptMapper.selectList(lqw);
        for (Adopt adopt : adoptList) {
            adopt.setPet(petMapper.selectById(adopt.getPid()));
        }
        return adoptList;
    }

    @Override
    @Transactional
    public boolean deleteonebyID(Integer id) {
        return userMapper.deleteById(id) == 1;
    }

    @Override
    @Transactional
    public boolean addoneuser(User user) {
        boolean flag = true;
        Long userCount = userMapper.selectCount(new QueryWrapper<User>().eq("username", user.getUsername()));
        //username重名了
        if(userCount > 0) flag =  false;
        else userMapper.insert(user);
        return flag;
    }

    @Override
    @Transactional
    public boolean updateoneuser(User user) {
        return userMapper.updateById(user) == 1;
    }

    @Override
    public Pagination queryusersbypage(int current, QueryWrapper qw) {
        IPage iPage = new Page(current, 10);
        IPage list;
        if (qw == null) list = userMapper.selectPage(iPage, null);
        else list = userMapper.selectPage(iPage, qw);
        return new Pagination(list.getCurrent(), list.getRecords(), list.getPages(), list.getTotal(), 10);
    }

    @Override
    public Pagination likequery(int current,String column, String condition) {
        QueryWrapper qw = new QueryWrapper<>();
        qw.like(column, condition);
        return queryusersbypage(current, qw);
    }

    @Override

    public User userlogin(String username, String password) {
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(User::getUsername, username).eq(User::getPassword, password);
        return userMapper.selectOne(lqw);
    }

}

