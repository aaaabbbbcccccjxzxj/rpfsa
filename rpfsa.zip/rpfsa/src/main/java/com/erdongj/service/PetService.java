package com.erdongj.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Pet;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/9 17:09
 * @Description:
 */
public interface PetService {

    /**
     * 查询所有收到宠宠币前10宠物
     *
     * @return
     */
    List<Pet> queryallpets();

    /**
     * 根据用户id返回该用户领养的所有动物
     *
     * @param uid
     * @return
     */
    List<Pet> querypetbyuid(Integer uid);

    /**
     * 根据ID查询宠物
     *
     * @param id
     * @return
     */
    Pet queryonebyID(Integer id);

    /**
     * 管理员根据ID删除宠物
     *
     * @param id
     * @return
     */
    boolean deleteonebyID(Integer id);

    /**
     * 添加一个宠物
     *
     * @param pet
     * @return
     */

    boolean addonepet(Pet pet);

    /**
     * 修改一个宠物
     *
     * @param pet
     * @return
     */
    boolean updateonepet(Pet pet);

    /**
     * 可按条件分页
     * @param current
     * @param qw
     * @return
     */
    Pagination querypetsbypage(int current, QueryWrapper qw);

    /**
     * 模糊查询,封装条件调分页查询
     *
     * @param current
     * @param column
     * @param condition
     * @return
     */
    Pagination conditionquery(int current, String column, String condition);

}
