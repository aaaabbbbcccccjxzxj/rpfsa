package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.erdongj.mapper.AdoptMapper;
import com.erdongj.mapper.PetMapper;
import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.Adopt;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Pet;
import com.erdongj.pojo.User;
import com.erdongj.service.AdoptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/23 09:54
 * @Description:
 */
@Service
public class AdoptServiceImpl implements AdoptService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PetMapper petMapper;
    @Autowired
    private AdoptMapper adoptMapper;

    @Override
    public Pagination queryadoptsbypage(int current, QueryWrapper qw) {
        IPage iPage = new Page(current, 10);
        IPage pageinfo;
        if (qw == null) pageinfo = adoptMapper.selectPage(iPage, null);
        else pageinfo = adoptMapper.selectPage(iPage, qw);
        List<Adopt> adoptList = pageinfo.getRecords();
        for (Adopt adopt : adoptList) {
            adopt.setUser(userMapper.selectById(adopt.getUid()));
            adopt.setPet(petMapper.selectById(adopt.getPid()));
        }
        return new Pagination(current, adoptList, pageinfo.getPages(), pageinfo.getTotal(), 12);
    }

    @Override
    public Pagination conditionquery(int current, String column, String condition) {
        QueryWrapper<Adopt> qw = new QueryWrapper<>();
        qw.like(column.equals("username"), column, condition)
                .like(column.equals("nickname"), column, condition)
                .like(column.equals("petname"), column, condition);
        return queryadoptsbypage(current, qw);
    }

    @Override
    @Transactional
    public boolean addadopttable(Adopt adopt) {
        return adoptMapper.insert(adopt) == 1;
    }


    @Override
    @Transactional
    public boolean deleteone(Integer id) {
        return adoptMapper.deleteById(id) == 1;
    }

    @Override
    @Transactional
    public boolean auditstatus(Adopt adopt) {
        return adoptMapper.updateById(adopt) == 1;
    }

    @Override
    @Transactional
    public boolean readalladopt(Integer uid) {
        LambdaQueryWrapper<Adopt> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Adopt::getUid, uid).eq(Adopt::getIsRead, 1);
        List<Adopt> adoptList = adoptMapper.selectList(lqw);
        for (Adopt adopt : adoptList) {
            adopt.setIsRead(0);
            adoptMapper.updateById(adopt);
        }
        return true;
    }

    @Override
    public Long queryallonread(Integer uid) {
        LambdaQueryWrapper<Adopt> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Adopt::getUid, uid).eq(Adopt::getIsRead, 1);
        return adoptMapper.selectCount(lqw);
    }


}
