package com.erdongj.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.pojo.Donate;
import com.erdongj.pojo.Pagination;

import java.util.List;
import java.util.Map;

/**
 * @Author: Erdong J
 * @Date: 2023/5/6 21:03
 * @Description:
 */
public interface DonateService {

    /**
     * 添加一条捐助记录
     * @param donate
     * @return
     */
    boolean addonedonate(Donate donate);

    /**
     * 根据用户id查询该用户所有捐助记录
     * @param id
     * @return
     */
    List<Donate> queryalldonatebyid(Integer id);

    /**
     * 查询捐助次数与总额前十名的用户
     * @return
     */
    List<Map<String, Object>> query10user();

    /**
     * 可按条件分页查询
     * @param current
     * @param qw
     * @return
     */
    Pagination queryalldonatebypage(int current, QueryWrapper qw);

    /**
     * 创建条件
     * @param current
     * @param column
     * @param condition
     * @return
     */
    Pagination conditionquery(int current,String column,String condition);

    /**
     * 管理员更新捐助品已分配状态
     * @param donate
     * @return
     */
    boolean updatedonatestate(Donate donate);

    /**
     * 用户读取所有未读的通知
     * @param id
     * @return
     */
    boolean readalladopt(Integer id);

    /**
     * 用户拿到未读通知的Count数
     * @param uid
     * @return
     */
    Long queryallnoread(Integer uid);

}
