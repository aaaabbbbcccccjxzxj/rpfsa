package com.erdongj.service;

import com.erdongj.pojo.Message;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/5/9 15:25
 * @Description:
 */
public interface MessageService {
    /**
     * 添加一条message记录
     *
     * @param message
     * @return
     */
    boolean addonemessage(Message message);

    /**
     * 根据用户id查询所有该用户的message
     *
     * @param uid
     * @return
     */
    List<Message> queryallmessagebyid(Integer uid);

    /**
     * 查询所有未读的Count
     *
     * @param uid      该用户的的message
     * @param identity 以该用户还是管理员的身份查询未读
     * @return
     */
    Long queryallnoread(Integer uid, String identity);

    /**
     * 修改所有未读为已读
     *
     * @param uid      该用户的的message
     * @param identity 以该用户还是管理员的身份查询未读
     * @return
     */
    boolean allhaveread(Integer uid, String identity);
}
