package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.erdongj.mapper.DonateMapper;
import com.erdongj.mapper.PetMapper;
import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.Adopt;
import com.erdongj.pojo.Donate;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.User;
import com.erdongj.service.DonateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @Author: Erdong J
 * @Date: 2023/5/6 21:04
 * @Description:
 */
@Service
public class DonateServiceImpl implements DonateService {


    @Autowired
    private DonateMapper donateMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private PetMapper petMapper;

    @Override
    @Transactional
    public boolean addonedonate(Donate donate) {
        return donateMapper.insert(donate) == 1;
    }

    @Override
    public List<Donate> queryalldonatebyid(Integer id) {
        LambdaQueryWrapper<Donate> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Donate::getUid, id);
        List<Donate> donates = donateMapper.selectList(lqw);
        for (Donate donate : donates) {
            donate.setPet(petMapper.selectById(donate.getPid()));
        }
        return donates;
    }

    @Override
    public List<Map<String, Object>> query10user() {
        QueryWrapper qw = new QueryWrapper();
        qw.select("uid,count(uid) as count,sum(total_price) as totalPrice");
        qw.groupBy("uid");
        qw.orderByDesc("sum(total_price)");
        qw.last("limit 10");
        List<Map<String, Object>> list = donateMapper.selectMaps(qw);
        for (Map<String, Object> map : list) {
            map.put("user", userMapper.selectById((Integer) map.get("uid")));
        }
        return list;
    }

    @Override
    public Pagination queryalldonatebypage(int current, QueryWrapper qw) {
        IPage page = new Page(current, 10);
        IPage pageinfo;
        if (qw == null) pageinfo = donateMapper.selectPage(page, null);
        else pageinfo = donateMapper.selectPage(page, qw);
        List<Donate> donateList = pageinfo.getRecords();
        for (Donate donate : donateList) {
            donate.setUser(userMapper.selectById(donate.getUid()));
            donate.setPet(petMapper.selectById(donate.getPid()));
        }
        return new Pagination(current, donateList, pageinfo.getPages(), pageinfo.getTotal(), 10);
    }


    @Override
    public Pagination conditionquery(int current, String column, String condition) {
        QueryWrapper<Donate> qw = new QueryWrapper<>();
        qw.like(column.equals("username"), column, condition)
                .like(column.equals("nickname"), column, condition)
                .like(column.equals("petname"), column, condition);
        return queryalldonatebypage(current, qw);
    }


    @Override
    public boolean updatedonatestate(Donate donate) {
        return donateMapper.updateById(donate) == 1;
    }

    public boolean readalladopt(Integer id) {
        LambdaQueryWrapper<Donate> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Donate::getUid, id).eq(Donate::getIsRead, 1);
        List<Donate> donates = donateMapper.selectList(lqw);
        for (Donate donate : donates) {
            donate.setIsRead(0);
            donateMapper.updateById(donate);
        }
        return true;
    }

    @Override
    public Long queryallnoread(Integer uid) {
        LambdaQueryWrapper<Donate> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Donate::getUid, uid).eq(Donate::getIsRead, 1);
        return donateMapper.selectCount(lqw);
    }
}
