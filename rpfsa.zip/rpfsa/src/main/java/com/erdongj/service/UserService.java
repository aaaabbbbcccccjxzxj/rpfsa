package com.erdongj.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.pojo.Adopt;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Pet;
import com.erdongj.pojo.User;

import java.util.List;

/**
 * @description: 用户业务层
 * @author: Erdong J
 * @create: 2023-03-16 21:31
 **/
public interface UserService {

    /**
     * 查询领养宠物前十的用户
     *
     * @return
     */
    List<User> queryallusers();

    /**
     * 根据ID查询用户
     *
     * @param id
     * @return
     */
    User queryonebyID(Integer id);

    /**
     * 查询本uid用户所领养的pet情况
     *
     * @param uid
     * @return
     */
    List<Adopt> querymyadopt(Integer uid);

    /**
     * 根据ID删除用户
     *
     * @param id
     * @return
     */
    boolean deleteonebyID(Integer id);

    /**
     * 添加一个用户
     *
     * @param user
     * @return
     */

    boolean addoneuser(User user);

    /**
     * 修改一个用户
     *
     * @param user
     * @return
     */
    boolean updateoneuser(User user);

    /**
     * 分页查询,可选条件
     *
     * @param current
     * @param qw
     * @return
     */
    Pagination queryusersbypage(int current, QueryWrapper qw);

    /**
     * 模糊查询,封装条件调分页查询
     *
     * @param current
     * @param column
     * @param condition
     * @return
     */
    Pagination likequery(int current, String column, String condition);

    /**
     * 用户登录判断
     *
     * @param username
     * @param password
     * @return
     */
    User userlogin(String username, String password);

}
