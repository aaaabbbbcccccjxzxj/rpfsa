package com.erdongj.service;

import java.util.Map;

/**
 * @description: 管理员服务层
 * @author: Erdong J
 * @create: 2023-03-08 21:21
 **/
public interface AdminService {

    /**
     * 管理员登录验证
     *
     * @param name
     * @param password
     * @return
     */
    boolean Login(String name, String password);

    /**
     * 管理员首页信息详情
     *
     * @return
     */
    Map<String, Long> getallinfo();
}
