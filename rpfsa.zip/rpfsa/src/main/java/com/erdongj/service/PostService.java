package com.erdongj.service;

import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Post;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:29
 * @Description:
 */
public interface PostService {
    //帖子的话，只有增加，删除，查询方法

    /**
     * 添加一个帖子
     * @param post
     * @return
     */
    boolean addonepost(Post post);

    /**
     * 根据postid找到对应post,修改该post评论数
     * @param post
     * @return
     */
    boolean updatecommentcount(Post post);

    /**
     * 删除一个帖子
     *
     * @param id
     * @return
     */
    boolean deleteonepost(Integer id);

    /**
     * 查询一个帖子
     * @param id
     * @return
     */
    Post queryonepostbyid(Integer id);

    /**
     * 根据用户id查询该用户所有帖子
     * @param id
     * @return
     */
    List<Post> queryallmypostbyid(Integer id);


    /**
     * 拿到所有的公告post
     * @return
     */
    List<Post> queryall(int classic);
    /**
     * 分页查询所有帖子
     * @param current
     * @param type
     * @return
     */
    Pagination queryallpostsbypage(int current, int type, String column, String condition);

    /**
     * 查询前评论数前十的帖子
     * @return
     */
    List<Post> query10posts();
}
