package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.erdongj.mapper.CommentMapper;
import com.erdongj.mapper.PetMapper;
import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.Comment;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Pet;
import com.erdongj.pojo.User;
import com.erdongj.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/9 17:13
 * @Description:
 */
@Service
public class PetServiceImpl implements PetService {


    @Autowired
    private PetMapper petMapper;

    @Autowired
    private CommentMapper commentMapper;

    @Autowired
    private UserMapper userMapper;


    /**
     * 宠物前10排行榜
     *
     * @return
     */
    @Override
    public List<Pet> queryallpets() {
        LambdaQueryWrapper<Pet> lqw = new LambdaQueryWrapper<>();
        lqw.orderByDesc(Pet::getPetCoin).last("limit 10");
        return petMapper.selectList(lqw);
    }

    /**
     * 查看用户领养的宠物
     *
     * @param uid
     * @return
     */
    @Override
    public List<Pet> querypetbyuid(Integer uid) {
        LambdaQueryWrapper<Pet> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Pet::getUid, uid).eq(Pet::getType, 1).or().eq(Pet::getUid, uid).eq(Pet::getIsAdopt, 1);
        return petMapper.selectList(lqw);
    }

    @Override
    public Pet queryonebyID(Integer id) {
        //拿到该宠物的所有一级评论
        LambdaQueryWrapper<Comment> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Comment::getPid, id).eq(Comment::getLevel, 0);
        //拿到该帖子的所有一级评论
        List<Comment> comments = commentMapper.selectList(lqw);
        for (Comment comment : comments) {
            List<Comment> levelTwoComments = commentMapper.selectList(new QueryWrapper<Comment>().eq("level", comment.getId()));
            for (Comment twocomment : levelTwoComments) {
                twocomment.setUser(userMapper.selectById(twocomment.getUid()));
            }
            //一级评论设置二级评论
            comment.setCommentList(levelTwoComments);
            comment.setUser(userMapper.selectById(comment.getUid()));
        }
        Pet pet = petMapper.selectById(id);
        //私人上传,添加主人信息。
        if (pet.getType() == 1) pet.setUser(userMapper.selectOne(new QueryWrapper<User>().eq("id", pet.getUid())));
        pet.setComments(comments);
        return pet;
    }

    @Override
    @Transactional
    public boolean deleteonebyID(Integer id) {
        return petMapper.deleteById(id) == 1;
    }

    @Override
    @Transactional
    public boolean addonepet(Pet pet) {
        return petMapper.insert(pet) == 1;
    }

    @Override
    @Transactional
    public boolean updateonepet(Pet pet) {
        return petMapper.updateById(pet) == 1;
    }

    @Override
    public Pagination querypetsbypage(int current, QueryWrapper qw) {
        IPage page = new Page(current, 12);
        IPage pageinfo;
        if (qw == null) pageinfo = petMapper.selectPage(page, null);
        else pageinfo = petMapper.selectPage(page, qw);
        List<Pet> pets = pageinfo.getRecords();
        for (Pet pet : pets)
            if (pet.getType() == 1) pet.setUser(userMapper.selectOne(new QueryWrapper<User>().eq("id", pet.getUid())));
        return new Pagination(pageinfo.getCurrent(), pets, pageinfo.getPages(), pageinfo.getTotal(), 10);
    }

    @Override
    public Pagination conditionquery(int current, String column, String condition) {
        QueryWrapper qw = new QueryWrapper<>();
        //判断column进行条件赋予
        if (column.equals("petname") || column.equals("variety")) {
            //走模糊查询(搜索)
            qw.like(column, condition);
        } else {
            //走eq查询
            qw.eq(column, condition);
        }
        return querypetsbypage(current, qw);
    }
}
