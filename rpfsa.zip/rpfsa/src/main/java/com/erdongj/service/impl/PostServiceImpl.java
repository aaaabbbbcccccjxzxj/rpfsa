package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.erdongj.mapper.CommentMapper;
import com.erdongj.mapper.PostMapper;
import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.Comment;
import com.erdongj.pojo.Pagination;
import com.erdongj.pojo.Post;
import com.erdongj.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:35
 * @Description:
 */
@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostMapper postMapper;

    @Autowired
    private CommentMapper commentMapper;

    @Autowired
    private UserMapper userMapper;

    @Override
    @Transactional
    public boolean addonepost(Post post) {
        return postMapper.insert(post) == 1;
    }

    @Override
    @Transactional
    public boolean updatecommentcount(Post post) {
        return postMapper.updateById(post) == 1;
    }

    @Override
    @Transactional
    public boolean deleteonepost(Integer id) {

        return postMapper.deleteById(id) == 1;
    }

    @Override
    public Post queryonepostbyid(Integer id) {
        LambdaQueryWrapper<Comment> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Comment::getPoid, id).eq(Comment::getLevel, 0);
        //拿到该帖子的所有一级评论
        List<Comment> comments = commentMapper.selectList(lqw);
        for (Comment comment : comments) {
            List<Comment> levelTwocomments = commentMapper.selectList(new QueryWrapper<Comment>().eq("level", comment.getId()));
            for (Comment twocomment : levelTwocomments) {
                twocomment.setUser(userMapper.selectById(twocomment.getUid()));
                twocomment.setPost(postMapper.selectById(id));
            }
            //一级评论设置二级评论
            comment.setCommentList(levelTwocomments);
            comment.setUser(userMapper.selectById(comment.getUid()));
            comment.setPost(postMapper.selectById(id));
        }
        Post post = postMapper.selectById(id);
        //设置该帖子时谁发的
        post.setUser(userMapper.selectById(post.getUid()));
        //设置该帖子的所有评论
        post.setComments(comments);
        return post;
    }

    @Override
    public List<Post> queryallmypostbyid(Integer id) {
        LambdaQueryWrapper<Post> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Post::getUid, id);
        List<Post> postList = postMapper.selectList(lqw);
        for (Post post : postList) {
            //在post里面放comments,在每个comment里面放user,是用户查询本帖子是用的
            LambdaQueryWrapper<Comment> clqw = new LambdaQueryWrapper<>();
            clqw.eq(Comment::getPoid, post.getId());
            List<Comment> comments = commentMapper.selectList(clqw);
            for (Comment comment : comments) {
                comment.setUser(userMapper.selectById(comment.getUid()));
            }
            post.setComments(comments);
        }
        return postList;
    }

    /**
     * 网站首页用的和admin中心
     *
     * @param classic
     * @return
     */
    @Override
    public List<Post> queryall(int classic) {
        //拿到所有type字段为1的帖子，classic为-1表示查全部
        QueryWrapper<Post> qw = new QueryWrapper<>();
        //拿到公告类型
        qw.eq("type", 1).orderByDesc("create_time")
                .eq(classic == 0, "classic", 0)
                .eq(classic == 1, "classic", 1)
                .eq(classic == 2, "classic", 2);
        List<Post> postList = postMapper.selectList(qw);
        return postList;
    }

    /**
     * 这个方法是   后台:post 0 /notices 1/ 前端：community 0
     *
     * @param current
     * @param type
     * @param column
     * @param condition
     * @return
     */
    @Override
    public Pagination queryallpostsbypage(int current, int type, String column, String condition) {
        IPage page = new Page(current, 12);
        QueryWrapper<Post> qw = new QueryWrapper<>();
        if (column != null) {
            if (column.equals("title")) qw.like(column, condition);
            else if (column.equals("uid")) qw.ne(column, condition);
            else qw.eq(column, condition);
        }
        //必做的条件
        qw.eq("type", type).orderByDesc("create_time");
        IPage pageinfo = postMapper.selectPage(page, qw);
        List<Post> postList = pageinfo.getRecords();
        if (type == 0) postadduserandcomm(postList);
        return new Pagination(current, postList, pageinfo.getPages(), pageinfo.getTotal(), 12);
    }

    @Override
    public List<Post> query10posts() {
        LambdaQueryWrapper<Post> lqw = new LambdaQueryWrapper<>();
        lqw.ne(Post::getUid, 0).orderByDesc(Post::getCommentCount).last("limit 10");
        List<Post> postList = postMapper.selectList(lqw);
        postadduserandcomm(postList);
        return postList;
    }

    public void postadduserandcomm(List<Post> postList) {
        for (Post post : postList) {
            post.setUser(userMapper.selectById(post.getUid()));
            LambdaQueryWrapper<Comment> lqwc = new LambdaQueryWrapper<>();
            lqwc.eq(Comment::getPoid, post.getId());
            List<Comment> comments = commentMapper.selectList(lqwc);
            for (Comment comment : comments) {
                //设置哪个用户评论的
                comment.setUser(userMapper.selectById(comment.getUid()));
                comment.setPost(postMapper.selectById(post.getId()));
            }
            post.setComments(comments);
        }
    }
}
