package com.erdongj.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.erdongj.mapper.JournalMapper;
import com.erdongj.mapper.PetMapper;
import com.erdongj.mapper.UserMapper;
import com.erdongj.pojo.Journal;
import com.erdongj.pojo.Pet;
import com.erdongj.pojo.User;
import com.erdongj.service.JournalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/6/3 15:55
 * @Description:
 */
@Service
public class JournalServiceImpl implements JournalService {

    @Autowired
    private JournalMapper journalMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PetMapper petMapper;

    @Override
    public boolean addonejournal(Journal journal) {
        return journalMapper.insert(journal) == 1;
    }

    @Override
    public boolean deleteonejournal(int id) {
        return journalMapper.deleteById(id) == 1;
    }

    @Override
    public List<Journal> queryonepetbyid(int pid) {
        List<Journal> journalList = journalMapper.selectList(new QueryWrapper<Journal>().eq("pid", pid).orderByDesc("create_time"));
        for (Journal journal : journalList) {
            journal.setUser(userMapper.selectOne(new QueryWrapper<User>().eq("id", journal.getUid())));
            journal.setPet(petMapper.selectOne(new QueryWrapper<Pet>().eq("id", journal.getPid())));
        }
        return journalList;
    }
}
