package com.erdongj.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:22
 * @Description:
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer uid;
    @TableField(exist = false)
    private User user; //是哪个用户评论的
    private Integer poid;
    private Integer pid; //与poid必须有一个为零.
    private Integer level; //0(默认):一级评论  ; 某一级评论id:二级评论
    @TableField(exist = false)
    private List<Comment> commentList; //当level为0时,才有子评论。
    @TableField(exist = false)
    private Post post; //归属哪个post
    private Date createTime;
    private String content;
    private Integer isDel;

    public Comment(Integer uid, Integer poid, String content) {
        this.uid = uid;
        this.poid = poid;
        this.content = content;
    }
}
