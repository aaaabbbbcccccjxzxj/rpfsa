package com.erdongj.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/9 17:03
 * @Description: 宠物实体表
 */
@Data
@NoArgsConstructor
public class Pet {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String petname;
    private String photo;
    private Integer sex;
    private Integer age;
    private Integer type;
    private Integer classic;
    private String variety;
    private Integer isVaccine;
    private Integer isAdopt;
    private Integer isDel;
    private Integer petCoin;
    private String describtion;
    private Integer commentCount;
    @TableField(exist = false)
    private List<Comment> comments; //用来存放该条帖子的评论
    private Date createTime;
    @TableField(exist = false)
    private User user;
    private Integer uid; //收养人id

}
