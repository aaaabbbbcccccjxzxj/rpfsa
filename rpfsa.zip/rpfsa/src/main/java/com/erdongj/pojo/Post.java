package com.erdongj.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Author: Erdong J
 * @Date: 2023/4/28 15:17
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Post {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String title;
    private String content;
    private Integer uid;
    @TableField(exist = false) //说明该帖子是谁发的
    private User user;
    private Integer classic; //管理员：0:网站公告,1:领养指南,2:近期新闻,3:社区置顶公告，用户：4:寻找猫狗，5：咨询领养，6：分享生活，7：其他
    private Integer type;  //0表示帖子，1表示公告
    private Integer commentCount;
    private Date createTime;
    private Integer isPinned;  //是否置顶 管理员可以修改
    @TableField(exist = false)
    private List<Comment> comments; //用来存放该条帖子的评论
    private Integer isDel;

}
