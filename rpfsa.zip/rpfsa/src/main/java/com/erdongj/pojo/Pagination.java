package com.erdongj.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @description: 存储分页查询
 * @author: Erdong J
 * @create: 2023-03-17 20:53
 **/


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pagination {
    private long current;
    private List records;
    //总页数
    private long pages;
    //records总数
    private long total;
    //每页显示条数
    private long size;
}

