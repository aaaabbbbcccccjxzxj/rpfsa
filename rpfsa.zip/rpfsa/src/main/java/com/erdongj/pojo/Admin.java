package com.erdongj.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: 管理员
 * @author: Erdong J
 * @create: 2023-03-08 19:35
 **/

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Admin {
    private String adminname;
    private String password;
}

