package com.erdongj.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Author: Erdong J
 * @Date: 2023/5/6 20:48
 * @Description:
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Donate {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer uid;
    @TableField(exist = false)
    private User user;
    private String username;
    private String nickname;
    private Integer pid;
    @TableField(exist = false)
    private Pet pet;
    private String petname;
    private String donateList;
    private Integer totalPrice;
    private Integer state;
    private Integer isRead;
    private Date createTime;
    private Integer isDel;
}
