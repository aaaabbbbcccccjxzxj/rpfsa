package com.erdongj.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: 统一返回结果集合
 * @author: Erdong J
 * @create: 2023-03-17 21:38
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResultBean {

    private int code; //返回状态码
    private String msg;   //返回本次请求消息
    private Object data;  //返回本次请求数据
}

