package com.erdongj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.erdongj.pojo.Adopt;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author: Erdong J
 * @Date: 2023/4/23 09:47
 * @Description:
 */
@Mapper
public interface AdoptMapper extends BaseMapper<Adopt> {
}
