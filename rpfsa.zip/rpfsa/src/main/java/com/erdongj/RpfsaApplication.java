package com.erdongj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpfsaApplication {

    public static void main(String[] args) {
        SpringApplication.run(RpfsaApplication.class, args);
    }

}
